import React from 'react';
import { useParams, useNavigate } from 'react-router-dom'; // Import useNavigate
import { useQuery, gql } from '@apollo/client';

const GET_TEAM_DETAILS = gql`
  query GetTeam($id: ID!) {
    team(id: $id) {
      id
      teamName
      description
      members {
        id
        username
        email
      }
      status
    }
  }
`;

const ViewTeamDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate(); // Initialize useNavigate
  const { data, loading, error } = useQuery(GET_TEAM_DETAILS, {
    variables: { id },
  });

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const team = data.team;

  return (
    <div style={containerStyle}>
      <h1>{team.teamName}</h1>

      {/* Display team details */}
      <div style={sectionStyle}>
        <p><strong>Description:</strong> {team.description}</p>
        <p><strong>Status:</strong> {team.status}</p>
      </div>

      {/* Display team members */}
      <div style={sectionStyle}>
        <h2>Members</h2>
        <ul>
          {team.members.map((member) => (
            <li key={member.id}>
              <strong>{member.username}</strong> ({member.email})
            </li>
          ))}
        </ul>
      </div>

      {/* Return Button */}
      <div style={buttonContainerStyle}>
        <button onClick={() => navigate('/dashboard')} style={buttonStyle}>
          Return to Dashboard
        </button>
      </div>
    </div>
  );
};

// Styles for readability
const containerStyle = {
  maxWidth: '800px',
  margin: 'auto',
  padding: '20px',
  background: '#f9f9f9',
  borderRadius: '8px',
  boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
};

const sectionStyle = {
  marginTop: '20px',
  padding: '10px 0',
  borderBottom: '1px solid #ccc',
};

const buttonContainerStyle = {
  marginTop: '20px',
  textAlign: 'center',
};

const buttonStyle = {
  padding: '10px 20px',
  background: '#007bff',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
  transition: 'background 0.3s',
};

export default ViewTeamDetails;
