import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, gql } from '@apollo/client';

const GET_PROJECT_DETAILS = gql`
  query GetProject($id: ID!) {
    project(id: $id) {
      id
      projectName
      description
      status
      team {
        id
        teamName
      }
    }
  }
`;

const ViewAssignedProjects = () => {
  const { id } = useParams(); // Extract id from URL
  const navigate = useNavigate(); // Initialize useNavigate for routing

  const { data, loading, error } = useQuery(GET_PROJECT_DETAILS, {
    variables: { id }, // Pass id to the query
  });

  if (loading) return <p>Loading...</p>;
  if (error) {
    console.error('GraphQL Error:', error); // Log the error for debugging
    return <p>Error: {error.message}</p>;
  }

  const project = data?.project;

  if (!project) {
    return <p>No project found with the provided ID.</p>;
  }

  return (
    <div style={containerStyle}>
      <h1>{project.projectName}</h1>

      {/* Display project details */}
      <div style={sectionStyle}>
        <p><strong>Description:</strong> {project.description}</p>
        <p><strong>Status:</strong> {project.status}</p>
        <p><strong>Team:</strong> {project.team.teamName}</p>
      </div>

      {/* Return Button */}
      <div style={buttonContainerStyle}>
        <button onClick={() => navigate('/dashboard')} style={buttonStyle}>
          Return to Dashboard
        </button>
      </div>
    </div>
  );
};

// Styles for readability
const containerStyle = {
  maxWidth: '800px',
  margin: 'auto',
  padding: '20px',
  background: '#f9f9f9',
  borderRadius: '8px',
  boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
};

const sectionStyle = {
  marginTop: '20px',
  padding: '10px 0',
  borderBottom: '1px solid #ccc',
};

const buttonContainerStyle = {
  marginTop: '20px',
  textAlign: 'center',
};

const buttonStyle = {
  padding: '10px 20px',
  background: '#007bff',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
  transition: 'background 0.3s',
};

export default ViewAssignedProjects;
