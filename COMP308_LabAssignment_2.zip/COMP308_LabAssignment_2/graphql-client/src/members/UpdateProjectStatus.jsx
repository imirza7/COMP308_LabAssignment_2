import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, gql } from '@apollo/client';
import { Container, Form, Button, Alert } from 'react-bootstrap';

const GET_PROJECTS = gql`
  query GetProjects {
    projects {
      id
      projectName
      status
    }
  }
`;

const UPDATE_PROJECT_STATUS_MUTATION = gql`
  mutation UpdateProjectStatus($id: ID!, $status: String!) {
    updateProjectStatus(id: $id, status: $status) {
      id
      projectName
      status
    }
  }
`;

const UpdateProjectStatus = () => {
  const navigate = useNavigate();
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [status, setStatus] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const { data, loading, error } = useQuery(GET_PROJECTS);
  
  const [updateProjectStatus] = useMutation(UPDATE_PROJECT_STATUS_MUTATION, {
    onError: (error) => {
      console.error('Error updating project status:', error);
      setErrorMessage(`Error updating project status: ${error.message}`);
    },
    onCompleted: (data) => {
      setSuccessMessage('Project status updated successfully!');
      setSelectedProjectId('');
      setStatus('');
    },
    refetchQueries: [{ query: GET_PROJECTS }]
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!selectedProjectId || !status) {
      setErrorMessage('Please select both a project and a status.');
      return;
    }

    try {
      const result = await updateProjectStatus({
        variables: {
          id: String(selectedProjectId), 
          status: status
        }
      });
      console.log('Mutation response:', result);
    } catch (err) {
      console.error('Mutation error:', {
        message: err.message,
        networkError: err.networkError?.result,
        graphQLErrors: err.graphQLErrors,
      });
    }
  };

  if (loading) return <Container className="mt-4"><Alert variant="info">Loading projects...</Alert></Container>;
  if (error) return <Container className="mt-4"><Alert variant="danger">Error loading projects: {error.message}</Alert></Container>;

  const projects = data?.projects || [];

  return (
    <Container className="mt-4" style={styles.container}>
      <h1 className="mb-4" style={styles.header}>Update Project Status</h1>

      {errorMessage && (
        <Alert variant="danger" onClose={() => setErrorMessage('')} dismissible style={styles.alert}>
          {errorMessage}
        </Alert>
      )}

      {successMessage && (
        <Alert variant="success" onClose={() => setSuccessMessage('')} dismissible style={styles.alert}>
          {successMessage}
        </Alert>
      )}

      <Form onSubmit={handleSubmit} className="mb-4" style={styles.form}>
        <Form.Group className="mb-3">
          <Form.Label>Select Project</Form.Label>
          <Form.Select
            value={selectedProjectId}
            onChange={(e) => setSelectedProjectId(e.target.value)}
            required
            style={styles.select}
          >
            <option value="">Choose a project...</option>
            {projects.map((project) => (
              <option key={project.id} value={project.id}>
                {project.projectName} (Current Status: {project.status})
              </option>
            ))}
          </Form.Select>
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Select Status</Form.Label>
          <Form.Select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            required
            style={styles.select}
          >
            <option value="">Choose a status...</option>
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </Form.Select>
        </Form.Group>

        <div className="d-flex gap-2" style={styles.buttonContainer}>
          <Button type="submit" variant="primary" style={styles.button}>
            Update Status
          </Button>
          <Button 
            variant="secondary"
            onClick={() => navigate('/dashboard')}
            style={styles.button}
          >
            Return to Dashboard
          </Button>
        </div>
      </Form>
    </Container>
  );
};

const styles = {
  container: {
    maxWidth: '800px',
    margin: 'auto',
    padding: '20px',
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
  },
  header: {
    textAlign: 'center',
    color: '#000',  // Black color for header
    fontSize: '2.5rem',
  },
  alert: {
    marginBottom: '20px',
  },
  form: {
    fontFamily: 'Arial, sans-serif',
  },
  select: {
    padding: '10px',
    margin: '10px 0',
    borderRadius: '5px',
    border: '1px solid #ccc',
    fontSize: '16px',
    width: '100%',
  },
  buttonContainer: {
    display: 'flex',
    gap: '10px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '16px',
    borderRadius: '5px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
  },
};

export default UpdateProjectStatus;
