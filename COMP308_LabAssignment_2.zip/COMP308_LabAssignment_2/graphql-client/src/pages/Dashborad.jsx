import React from 'react';
import { useQuery, gql } from '@apollo/client';
import { Link } from 'react-router-dom'; // Import Link for navigation

const GET_TEAMS_AND_PROJECTS = gql`
  query GetTeamsAndProjects {
    teams {
      id
      teamName
      description
    }
    projects {
      id
      projectName
      description
      status
    }
  }
`;

const Dashboard = () => {
  const { data, loading, error } = useQuery(GET_TEAMS_AND_PROJECTS);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const { teams, projects } = data;

  return (
    <div style={styles.container}>
      <h1 style={styles.mainHeading}>Member Dashboard</h1>

      {/* Navigation Links */}
      <nav style={styles.nav}>
        <Link to="/update-project-status" style={styles.link}>Update Project Status</Link>
      </nav>

      {/* Team List */}
      <h2 style={styles.teamHeading}>Teams</h2>
      <ul style={styles.list}>
        {teams.map((team) => (
          <li key={team.id} style={styles.listItem}>
            <Link to={`/team/${team.id}`} style={styles.link}>{team.teamName}</Link> {/* Link to team details */}
          </li>
        ))}
      </ul>

      {/* Projects List */}
      <h2 style={styles.projectHeading}>Projects</h2>
      <ul style={styles.list}>
        {projects.map((project) => (
          <li key={project.id} style={styles.listItem}>
            <Link to={`/projects/${project.id}`} style={styles.link}>{project.projectName}</Link> {/* Link to project details */}
          </li>
        ))}
      </ul>
    </div>
  );
};

const styles = {
  container: {
    fontFamily: 'Arial, sans-serif',
    maxWidth: '1000px',
    margin: '0 auto',
    padding: '20px',
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  },
  mainHeading: {
    textAlign: 'center',
    color: '#000',  // Black color for the main heading
    fontSize: '2.5rem',
    marginBottom: '20px',
  },
  teamHeading: {
    color: '#000',  // Black color for Teams heading
    marginBottom: '10px',
  },
  projectHeading: {
    color: '#000',  // Black color for Projects heading
    marginBottom: '10px',
  },
  list: {
    listStyleType: 'none',
    paddingLeft: '0',
  },
  listItem: {
    padding: '10px',
    marginBottom: '8px',
    backgroundColor: '#fff',
    borderRadius: '5px',
    boxShadow: '0 1px 4px rgba(0, 0, 0, 0.1)',
  },
  nav: {
    marginBottom: '20px',
    textAlign: 'center',
  },
  link: {
    textDecoration: 'none',
    color: '#007bff', // Blue color for links
    fontSize: '1.1rem',
  },
};

export default Dashboard;
